<?php
// dbcon.php - การเชื่อมต่อฐานข้อมูล MySQL

$servername = "localhost";  // ชื่อเซิร์ฟเวอร์ฐานข้อมูล
$username = "root";         // ชื่อผู้ใช้ฐานข้อมูล
$password = "123456789";    // รหัสผ่านฐานข้อมูล
$dbname = "apartmentV2";    // ชื่อฐานข้อมูล

try {
    // สร้างการเชื่อมต่อด้วย PDO
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // ตั้งค่า PDO error mode เป็น exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Optionally, test the connection by echoing success message
    // echo "Connected successfully!";
} catch(PDOException $e) {
    // Log the error message to a file for debugging
    error_log("Connection failed: " . $e->getMessage());
    
    // Show user-friendly message and exit
    die("Connection failed. Please try again later.");
}
?>
