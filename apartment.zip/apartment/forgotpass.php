<?php
require 'dbcon.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];

    try {
        // ตรวจสอบว่าอีเมลมีอยู่ในระบบ
        $sql = "SELECT * FROM register WHERE email = :email";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':email', $email);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            // อีเมลมีอยู่ในระบบ ให้ไปที่หน้า reset_password.php
            header("Location: reset_password.php?email=" . urlencode($email));
            exit();
        } else {
            echo "<script>alert('Email not found in our system.');</script>";
        }
    } catch (PDOException $e) {
        echo "<script>alert('Database Error: " . $e->getMessage() . "');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Forgot Password</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: linear-gradient(135deg, #6e8efb, #a777e3);
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 20px;
      margin: 0;
    }

    .card {
      border: none;
      border-radius: 15px;
      background: #fff;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
    }

    .card-header {
      text-align: center;
      font-size: 1.8rem;
      font-weight: 700;
      color: #6e8efb;
      background: transparent;
      border-bottom: none;
      padding-top: 20px;
    }

    .card-body {
      padding: 30px;
    }

    .form-control:focus {
      box-shadow: 0 0 0 0.2rem rgba(110, 142, 251, 0.4);
      border-color: #6e8efb;
    }

    .btn-primary {
      background: linear-gradient(135deg, #6e8efb, #a777e3);
      border: none;
      font-size: 1rem;
      padding: 10px 20px;
      transition: all 0.3s ease-in-out;
    }

    .btn-primary:hover {
      background: linear-gradient(135deg, #a777e3, #6e8efb);
      transform: scale(1.05);
    }

    .login-link {
      text-decoration: none;
      color: #6e8efb;
      font-size: 0.9rem;
    }

    .login-link:hover {
      color: #a777e3;
      text-decoration: underline;
    }

    .text-center p {
      font-size: 1rem;
      color: #555;
    }
  </style>
  </style>
</head>

<body>
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-6 col-lg-5">
        <div class="card">
          <div class="card-header">
            Forgot Password
          </div>
          <div class="card-body">
            <p class="text-center mb-4">
              Enter your registered email address, and we will send you instructions to reset your password.
            </p>
            <form action="" method="POST">
              <div class="mb-3">
                <label for="email" class="form-label">Email Address</label>
                <input type="email" class="form-control" id="email" name="email" placeholder="Enter your email" required>
              </div>
              <div class="d-grid">
                <button type="submit" class="btn btn-primary">Send Reset Link</button>
              </div>
              <div class="text-center mt-4">
                <a href="login.php" class="login-link">Back to Login</a>
              </div>
            </form>

          </div>
        </div>
      </div>
    </div>
  </div>
</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>

</html>