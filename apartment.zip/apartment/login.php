<?php
// เริ่ม session ถ้าต้องการใช้ session สำหรับการจัดการการเข้าสู่ระบบ
session_start();

// รวมไฟล์การเชื่อมต่อฐานข้อมูล
require 'dbcon.php';  // เรียกไฟล์ dbcon.php ที่เราแยกไว้

$message = ''; // ตัวแปรเพื่อเก็บข้อความผิดพลาด

// ตรวจสอบว่ามีการส่งฟอร์มหรือไม่
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // รับค่าจากฟอร์ม
    $email = isset($_POST['email']) ? $_POST['email'] : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';

    // ตรวจสอบว่ามีอีเมลในระบบหรือไม่
    $sql = "SELECT * FROM profile WHERE email = :email";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':email', $email, PDO::PARAM_STR);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($result) {
        // ถ้ามีผู้ใช้ในระบบ
        // ตรวจสอบรหัสผ่าน
        if (password_verify($password, $result['password'])) {
            // ถ้ารหัสผ่านถูกต้อง
            $_SESSION['user_id'] = $result['id'];  // เก็บ ID ผู้ใช้ใน session
            $_SESSION['user_name'] = $result['name']; // เก็บชื่อผู้ใช้ใน session
            $_SESSION['role'] = $result['role'];  // เก็บ role ของผู้ใช้ใน session

            // แยกการเข้าถึงตาม role
            switch ($result['role']) {
                case 'admin':
                    header("Location: admin/index.php"); // ถ้าเป็น admin ให้ไปหน้า admin
                    exit;
                case 'employee':
                    header("Location: employee/index.php"); // ถ้าเป็น employee ให้ไปหน้า employee
                    exit;
                case 'tenant':
                    header("Location: tenant/index.php"); // ถ้าเป็น tenant ให้ไปหน้า tenant
                    exit;
                default:
                    $message = "Invalid role.";
                    break;
            }
        } else {
            // ถ้ารหัสผ่านไม่ตรง
            $message = "Invalid password.";
        }
    } else {
        // ถ้าไม่พบอีเมลในระบบ
        $message = "No account found with this email.";
    }
}

// ปิดการเชื่อมต่อฐานข้อมูล
$conn = null;
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login Page with Bootstrap 5</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <style>
    body {
      background: linear-gradient(135deg, #6e8efb, #a777e3);
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      margin: 0;
      padding: 20px;
    }

    .card {
      border: none;
      border-radius: 15px;
      background: #fff;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
    }

    .card-header {
      text-align: center;
      font-size: 1.8rem;
      font-weight: 700;
      color: #6e8efb;
      background: transparent;
      border-bottom: none;
      padding-top: 20px;
    }

    .form-control {
      height: 50px;
      font-size: 0.95rem;
      border-radius: 8px;
    }

    .form-control:focus {
      box-shadow: 0 0 0 0.2rem rgba(110, 142, 251, 0.4);
      border-color: #6e8efb;
    }

    .btn-primary {
      background: linear-gradient(135deg, #6e8efb, #a777e3);
      border: none;
      padding: 12px 20px;
      font-size: 1rem;
      transition: all 0.3s ease-in-out;
    }

    .btn-primary:hover {
      background: linear-gradient(135deg, #a777e3, #6e8efb);
      transform: scale(1.05);
    }

    .forgot-password {
      text-decoration: none;
      color: #6e8efb;
      font-weight: 600;
      font-size: 0.9rem;
      transition: color 0.3s ease-in-out;
    }

    .forgot-password:hover {
      color: #a777e3;
      text-decoration: underline;
    }

    .text-center {
      margin-top: 20px;
    }

    .text-center a+a {
      margin-left: 10px;
    }
  </style>
</head>

<body>
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-6 col-lg-4">
        <div class="card">
          <div class="card-header">
            Login
          </div>
          <div class="card-body">
            <form action="" method="POST">
              <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" name="email" placeholder="Enter your email" required>
              </div>
              <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" id="password" name="password" placeholder="Enter your password" required>
              </div>
              <div class="d-grid">
                <button type="submit" class="btn btn-primary">Login</button>
              </div>
              <div class="text-center mt-3">
                <a href="forgotpass.php" class="forgot-password">Forgot Password?</a>
                <a href="register.php" class="forgot-password">Register?</a>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>

  <?php if (!empty($message)) : ?>
  <script>
    document.addEventListener("DOMContentLoaded", function() {
      Swal.fire({
        title: "Error",
        text: "<?php echo $message; ?>",
        icon: "error",
        confirmButtonText: "OK"
      });
    });
  </script>
  <?php endif; ?>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
