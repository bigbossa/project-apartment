<?php
// เริ่มต้นเซสชัน
session_start();

// ตรวจสอบการลบเซสชันจะทำหลังจากกดปุ่มยืนยันใน SweetAlert
if (isset($_GET['logout']) && $_GET['logout'] == 'true') {
    session_unset(); // ลบตัวแปรทั้งหมดในเซสชัน
    session_destroy(); // ทำลายเซสชัน
    header("Location: index.php"); // เปลี่ยนเส้นทางไปยังหน้าแรก
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logout</title>
    <!-- เพิ่ม SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
    <script>
        // แสดง SweetAlert พร้อมปุ่มยืนยันและยกเลิก
        Swal.fire({
            title: 'คุณต้องการออกจากระบบหรือไม่?',
            text: 'หากออกจากระบบ คุณจะต้องเข้าสู่ระบบอีกครั้ง',
            icon: 'warning',
            showCancelButton: true, // แสดงปุ่มยกเลิก
            confirmButtonText: 'ออกจากระบบ',
            cancelButtonText: 'ยกเลิก',
            reverseButtons: true, // สลับตำแหน่งปุ่ม
        }).then((result) => {
            if (result.isConfirmed) {
                // หากกด "ออกจากระบบ" ให้เปลี่ยนเส้นทางไปยัง URL ที่ทำลายเซสชัน
                window.location.href = 'index.php';
            } else if (result.dismiss === Swal.DismissReason.cancel) {
                // หากกด "ยกเลิก" ให้เปลี่ยนเส้นทางกลับไปหน้าหลักหรือหน้าก่อนหน้า
                window.location.href = 'admin/index.php'; // เปลี่ยนไปที่หน้าที่ต้องการ
            }
        });
    </script>
</body>
</html>
