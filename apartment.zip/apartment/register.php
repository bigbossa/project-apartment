<?php
// เริ่มต้น session
session_start();

// รวมไฟล์การเชื่อมต่อฐานข้อมูล
require 'dbcon.php'; // ไฟล์ dbcon.php ควรมี $conn สำหรับเชื่อมต่อ MySQL

// ตัวแปรสำหรับส่งข้อมูล SweetAlert
$sweetAlert = "";

// ตรวจสอบว่ามีการส่งฟอร์มหรือไม่
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // รับค่าจากฟอร์ม
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirmPassword'];

    // ตรวจสอบว่ารหัสผ่านตรงกันหรือไม่
    if ($password != $confirmPassword) {
        $sweetAlert = "
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Passwords do not match!'
            });
        ";
    } else {
        // แฮชรหัสผ่าน
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // ตรวจสอบว่าอีเมลซ้ำหรือไม่
        $checkEmailQuery = "SELECT * FROM Profile WHERE email = '$email'";
        $result = $conn->query($checkEmailQuery);

        if ($result->num_rows > 0) {
            $sweetAlert = "
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Email already exists!'
                });
            ";
        } else {
            // เพิ่มข้อมูลลงในฐานข้อมูล
            $sql = "INSERT INTO Profile (name, email, password, role) VALUES ('$name', '$email', '$hashedPassword', 'tenant')";

            if ($conn->query($sql) === TRUE) {
                $sweetAlert = "
                    Swal.fire({
                        icon: 'success',
                        title: 'Success',
                        text: 'Registration Successful!'
                    }).then(() => {
                        window.location.href = 'login.php';
                    });
                ";
            } else {
                $sweetAlert = "
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'An error occurred. Please try again later.'
                    });
                ";
            }
        }
    }
}

// ปิดการเชื่อมต่อฐานข้อมูล
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body {
            background: linear-gradient(135deg, #6e8efb, #a777e3);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 0;
            padding: 20px;
        }
        .card {
            border: none;
            border-radius: 15px;
            background: #fff;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }
        .card-header {
            text-align: center;
            font-size: 1.8rem;
            font-weight: 700;
            color: #6e8efb;
            background: transparent;
            border-bottom: none;
            padding-top: 20px;
        }
        .form-control {
            height: 50px;
            font-size: 0.95rem;
            border-radius: 8px;
        }
        .btn-primary {
            background: linear-gradient(135deg, #6e8efb, #a777e3);
            border: none;
            padding: 12px 20px;
            font-size: 1rem;
            transition: all 0.3s ease-in-out;
        }
        .btn-primary:hover {
            background: linear-gradient(135deg, #a777e3, #6e8efb);
            transform: scale(1.05);
        }
        .login-link {
            text-decoration: none;
            color: #6e8efb;
            font-weight: 600;
            font-size: 0.9rem;
        }
        .login-link:hover {
            color: #a777e3;
            text-decoration: underline;
        }
        .text-center p {
            font-size: 0.95rem;
            color: #555;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-5">
                <div class="card">
                    <div class="card-header">
                        Register
                    </div>
                    <div class="card-body">
                        <form action="" method="POST">
                            <div class="mb-3">
                                <label for="name" class="form-label">Full Name</label>
                                <input type="text" class="form-control" id="name" name="name" placeholder="Enter your full name" required>
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email Address</label>
                                <input type="email" class="form-control" id="email" name="email" placeholder="Enter your email" required>
                            </div>
                            <div class="mb-3">
                                <label for="password" class="form-label">Password</label>
                                <input type="password" class="form-control" id="password" name="password" placeholder="Create a password" required>
                            </div>
                            <div class="mb-3">
                                <label for="confirmPassword" class="form-label">Confirm Password</label>
                                <input type="password" class="form-control" id="confirmPassword" name="confirmPassword" placeholder="Confirm your password" required>
                            </div>
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary">Register</button>
                            </div>
                            <div class="text-center mt-4">
                                <span>Already have an account? </span>
                                <a href="login.php" class="login-link">Login</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- สคริปต์สำหรับแสดง SweetAlert -->
    <script>
        <?= $sweetAlert ?>
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
