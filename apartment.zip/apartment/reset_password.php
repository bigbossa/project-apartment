<?php
require 'dbcon.php';

// ตรวจสอบว่าได้รับอีเมลจาก URL
if (isset($_GET['email'])) {
    $email = $_GET['email'];

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $newPassword = $_POST['newPassword'];
        $confirmPassword = $_POST['confirmPassword'];

        // ตรวจสอบว่า รหัสผ่านใหม่และการยืนยันรหัสผ่านตรงกัน
        if ($newPassword === $confirmPassword) {
            try {
                // แฮชรหัสผ่านใหม่
                $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

                // อัพเดตฐานข้อมูลด้วยรหัสผ่านใหม่
                $sql = "UPDATE register SET password = :password WHERE email = :email";
                $stmt = $conn->prepare($sql);
                $stmt->bindParam(':password', $hashedPassword);
                $stmt->bindParam(':email', $email);
                $stmt->execute();

                echo "<script>alert('Password reset successful!'); window.location='login.php';</script>";
            } catch (PDOException $e) {
                echo "<script>alert('Database Error: " . $e->getMessage() . "');</script>";
            }
        } else {
            echo "<script>alert('Passwords do not match!');</script>";
        }
    }
} else {
    echo "<script>alert('Invalid request.'); window.location='forgot_password.php';</script>";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
    body {
      background: linear-gradient(135deg, #6e8efb, #a777e3);
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 20px;
      margin: 0;
    }
    .card {
      border: none;
      border-radius: 15px;
      background: #fff;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
    }
    .card-header {
      text-align: center;
      font-size: 1.8rem;
      font-weight: 700;
      color: #6e8efb;
      background: transparent;
      border-bottom: none;
      padding-top: 20px;
    }
    .card-body {
      padding: 30px;
    }
    .form-control:focus {
      box-shadow: 0 0 0 0.2rem rgba(110, 142, 251, 0.4);
      border-color: #6e8efb;
    }
    .btn-primary {
      background: linear-gradient(135deg, #6e8efb, #a777e3);
      border: none;
      font-size: 1rem;
      padding: 10px 20px;
      transition: all 0.3s ease-in-out;
    }
    .btn-primary:hover {
      background: linear-gradient(135deg, #a777e3, #6e8efb);
      transform: scale(1.05);
    }
    .login-link {
      text-decoration: none;
      color: #6e8efb;
      font-size: 0.9rem;
    }
    .login-link:hover {
      color: #a777e3;
      text-decoration: underline;
    }
    .text-center p {
      font-size: 1rem;
      color: #555;
    }
  </style>
</head>
<body>
<div class="container">
    <div class="row justify-content-center">
      <div class="col-md-6 col-lg-5">
        <div class="card">
          <div class="card-header">
            Reset Password
          </div>
          <div class="card-body">
            <p class="text-center mb-4">
              Enter your new password below. Make sure it's strong and secure.
            </p>
            <form action="" method="POST">
              <div class="mb-3">
                <label for="newPassword" class="form-label">New Password</label>
                <input type="password" class="form-control" id="newPassword" name="newPassword" placeholder="Enter your new password" required>
              </div>
              <div class="mb-3">
                <label for="confirmPassword" class="form-label">Confirm New Password</label>
                <input type="password" class="form-control" id="confirmPassword" name="confirmPassword" placeholder="Confirm your new password" required>
              </div>
              <div class="d-grid">
                <button type="submit" class="btn btn-primary">Reset Password</button>
              </div>
              <div class="text-center mt-4">
                <a href="login.php" class="login-link">Back to Login</a>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
