<?php

    include 'head.php';
    include 'Spinner.php';
    include 'Sidebar.php';
    include 'Content.php';
    include 'Backtotop.php';
    include 'JavaScript.php';

?>