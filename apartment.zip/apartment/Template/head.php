<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>หอพักบ้านพุทธชาติ</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="../img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Roboto:wght@500;700&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="../lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="/lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="../css/style.css" rel="stylesheet">
    <!-- เพิ่ม SweetAlert ในส่วน <head> -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <link href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>

</head>
<style>
    .custom-box {
        display: inline-block;
        /* ขนาดอิงตามเนื้อหา */
        background-color: #1c1c24;
        /* สีเทา (bg-secondary) */
        color: #CCCCCC;
        /* สีข้อความ */
        border-radius: 0.5rem;
        /* ขอบมน */
        word-wrap: break-word;
        /* ตัดข้อความ */

        padding: 1rem;
        /* เว้นระยะด้านใน */
    }

    .card {
        background-color: #242424;
        /* พื้นหลังการ์ดสีเข้ม */
        border: none;
        /* ลบเส้นขอบ */
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        /* เงา */
        border-radius: 10px;
        /* ขอบมน */
    }

    .card-title {
        color: #ffffff;
        /* สีข้อความในการ์ด */
        font-size: 18px;
    }

    /* เปลี่ยนสีการ์ดเมื่อโฮเวอร์ */
    .card:hover {
        background-color: #f0f0f0;
        /* เปลี่ยนพื้นหลัง */
        transform: scale(1.05);
        /* เพิ่มเอฟเฟกต์ขยายเล็กน้อย */
        transition: all 0.3s ease;
        /* เพิ่มความนุ่มนวลของการเปลี่ยนแปลง */
        cursor: pointer;
        /* เปลี่ยนเคอร์เซอร์เมื่อโฮเวอร์ */
    }

    /* เปลี่ยนสีข้อความเมื่อโฮเวอร์ */
    .card:hover .card-title {
        color: #007bff;
        /* สีข้อความเมื่อโฮเวอร์ */
        font-weight: bold;
    }
</style>

</style>

<body>
    <div class="container-fluid position-relative d-flex p-0"></div>