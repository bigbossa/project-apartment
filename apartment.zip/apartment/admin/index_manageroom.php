<?php
session_start();
include '../condb.php'; // เชื่อมต่อกับฐานข้อมูล
include '../Template/head.php';
include '../Template/sidebar/Sidebar_Showuser_room.php';
include '../Template/Navbar.php';

// ตรวจสอบว่ามีการส่งข้อมูลมาจากฟอร์มหรือไม่
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // รับค่าจากฟอร์ม
    $room_num = $_POST['room_num'];
    $price = $_POST['price'];
    $status = $_POST['status'];

    // ใช้ Prepared Statement เพื่อลดความเสี่ยงจาก SQL Injection
    $sql = $conn->prepare("INSERT INTO Rooms (room_num, price, status) VALUES (?, ?, ?)");
    $sql->bind_param("sss", $room_num, $price, $status);

    // ตรวจสอบว่าเพิ่มข้อมูลสำเร็จหรือไม่
    if ($sql->execute()) {
        echo "<script>alert('เพิ่มข้อมูลห้องพักสำเร็จ!');</script>";
    } else {
        echo "เกิดข้อผิดพลาด: " . $conn->error;
    }
}

?>

<div class="container-fluid pt-4 px-4">
    <div class="row">
        <!-- ฟอร์มเพิ่มข้อมูลห้องพัก -->
        <div class="col-sm-12 col-xl-6">
            <div class="bg-secondary rounded h-100 p-4">
                <form method="POST" action="">
                    <h1>เพิ่มข้อมูลห้องพัก</h1>
                    <div class="form-floating mb-3 ">
                        <input class="form-control" type="text" id="room_num" name="room_num" required>
                        <label for="room_num">หมายเลขห้อง</label>
                    </div>
                    <div class="form-floating mb-3">
                        <input class="form-control" type="number" id="price" name="price" required>
                        <label for="price">ราคา</label>
                    </div>
                    <div class="form-floating mb-3">
                        <select class="form-select" id="status" name="status" required>
                            <option value="available">ว่าง</option>
                            <option value="unavailable">ไม่ว่าง</option>
                        </select>
                        <label for="status">สถานะห้องพัก</label>
                    </div>
                    <input class="btn btn-primary" type="submit" value="เพิ่มข้อมูล">
                </form>
            </div>
        </div>

       <!-- ฟอร์มเพิ่มข้อมูลผู้เช่า -->
<div class="col-sm-12 col-xl-6">
    <div class="bg-secondary rounded h-100 p-4">
        <form method="POST" action="add_tenant.php">
            <h1>เพิ่มข้อมูลผู้เช่า</h1>
            <div class="form-floating mb-3">
                <input class="form-control" type="text" id="room_num" name="room_num" required>
                <label for="room_num">หมายเลขห้อง</label>
            </div>
            <div class="form-floating mb-3">
                <input class="form-control" type="text" id="name" name="name" required>
                <label for="name">ชื่อผู้เช่า</label>
            </div>
            <div class="form-floating mb-3">
                <input class="form-control" type="email" id="email" name="email" required>
                <label for="email">อีเมล</label>
            </div>
            <div class="form-floating mb-3">
                <input class="form-control" type="tel" id="phonenumber" name="phonenumber" required>
                <label for="phonenumber">เบอร์โทรศัพท์</label>
            </div>
            <div class="form-floating mb-3">
                <input class="form-control" type="text" id="address" name="address" required>
                <label for="address">ที่อยู่</label>
            </div>
            <div class="form-floating mb-3">
                <input class="form-control" type="number" id="idcard" name="idcard" required>
                <label for="idcard">เลขบัตรประชาชน</label>
            </div>
            <input class="btn btn-primary" type="submit" value="เพิ่มข้อมูลผู้เช่า">
        </form>
    </div>
</div>
</div>


<?php
// ปิดการเชื่อมต่อฐานข้อมูล
$conn->close();
?>
<?php
include '../Template/Footer.php';
include '../Template/Backtotop.php';
include '../Template/JavaScript.php';
?>
