<?php
ob_start(); // เริ่มบัฟเฟอร์
session_start();
include '../Template/head.php';
include '../Template/sidebar/Sidebar_Showuser.php';
include '../Template/Navbar.php';

require '../dbcon.php';

// ตรวจสอบการเข้าสู่ระบบ
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit();
}

if (isset($_GET['id'])) {
    $user_id = $_GET['id'];

    // ดึงข้อมูลผู้ใช้จากฐานข้อมูล
    $sql = "SELECT * FROM profile WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
    } else {
        echo "<script>
                Swal.fire('Error', 'User not found.', 'error').then(() => {
                    window.location.href = 'index_showuser.php';
                });
              </script>";
        exit();
    }
} else {
    echo "<script>
            Swal.fire('Error', 'Invalid request.', 'error').then(() => {
                window.location.href = 'index_showuser.php';
            });
          </script>";
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // รับค่าที่แก้ไขจากฟอร์ม
    $name = $_POST['name'];
    $email = $_POST['email'];
    $role = $_POST['role'];

    // อัปเดตข้อมูลในฐานข้อมูล
    $update_sql = "UPDATE profile SET name = ?, email = ?, role = ? WHERE id = ?";
    $update_stmt = $conn->prepare($update_sql);
    $update_stmt->bind_param("sssi", $name, $email, $role, $user_id);

    if ($update_stmt->execute()) {
        echo "<script>
                Swal.fire('Success', 'User updated successfully!', 'success').then(() => {
                    window.location.href = 'index_showuser.php';
                });
              </script>";
        exit();
    } else {
        echo "<script>
                Swal.fire('Error', 'Error updating user.', 'error');
              </script>";
    }
}

$conn->close();
?>

<div class="container-fluid pt-4 px-4">
    <div class="row vh-100 bg-secondary rounded align-items-center justify-content-center mx-0">
        <div class="col-md-6">
            <div class="container mt-5 p-5">
                <h2>Edit User</h2>
                <form action="" method="POST">
                    <div class="mb-3">
                        <label for="name" class="form-label">Name</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($user['name']); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="role" class="form-label">Role</label>
                        <select class="form-select" id="role" name="role" required>
                            <option value="admin" <?php echo ($user['role'] == 'admin') ? 'selected' : ''; ?>>Admin</option>
                            <option value="employee" <?php echo ($user['role'] == 'employee') ? 'selected' : ''; ?>>Employee</option>
                            <option value="tenant" <?php echo ($user['role'] == 'tenant') ? 'selected' : ''; ?>>Tenant</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                    <a href="index_showuser.php" class="btn btn-secondary">Cancel</a>
                </form>
            </div>
        </div>
    </div>
</div>

<?php
include '../Template/Footer.php';
include '../Template/Backtotop.php';
include '../Template/JavaScript.php';
?>

<!-- เพิ่ม SweetAlert -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
