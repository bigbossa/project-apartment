<?php

// เริ่มต้น session เพื่อเข้าถึงข้อมูล session ที่เก็บไว้
session_start();

// ตรวจสอบว่า session 'role' เป็น 'admin' หรือไม่
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    // ถ้าไม่ใช่ admin หรือไม่มี session 'role' แสดงว่าไม่ได้รับสิทธิ์
    header("Location: ../login.php");  // เปลี่ยนเส้นทางไปยังหน้า login
    exit();
}

// ถ้าเป็น admin ให้แสดงเนื้อหาด้านล่าง


    include '../Template/head.php';
    include '../Template/Spinner.php';
    include '../Template/sidebar/Sidebar_Dashbord.php';
    include '../Template/Navbar.php';
    // include '../Template/Content.php';
    include 'Content/Room.php';
    include '../Template/Footer.php';
    include '../Template/Backtotop.php';
    include '../Template/JavaScript.php';

?>