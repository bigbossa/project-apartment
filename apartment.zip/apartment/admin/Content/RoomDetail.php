<?php
session_start();
include '../../condb.php';

// Get the room ID from the URL
$room_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($room_id > 0) {
    // Fetch room and tenant data based on room_id
    $sql = "SELECT Rooms.*, profile.name, profile.email, profile.phonenumber, profile.address, profile.idcard
            FROM Rooms 
            LEFT JOIN profile ON profile.room_num = Rooms.room_num 
            WHERE Rooms.id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $room_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        $room = $result->fetch_assoc();
    } else {
        $error_message = "ไม่พบข้อมูลห้องพัก";
    }
} else {
    $error_message = "ไม่พบห้องพักที่เลือก";
}

// Close database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>รายละเอียดห้องพัก</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            margin: 0;
            padding: 0;
            background-color: #191c24;
            color: white;
            font-family: Arial, sans-serif;
        }
        .container-fluid {
            width: 100%;
            padding: 20px;
        }
        .content-wrapper {
            background-color: #242731;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            max-width: 900px;
            margin: 0 auto;
        }
        h1 {
            text-align: center;
            margin-bottom: 20px;
        }
        .detail {
            margin-bottom: 20px;
        }
        .label {
            font-weight: bold;
        }
        .status-available {
            color: green;
        }
        .status-unavailable {
            color: red;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="content-wrapper">
            <?php if (isset($room)): ?>
                <h1>รายละเอียดของห้อง <?php echo htmlspecialchars($room['room_num']); ?></h1>
                <div class="detail">
                    <p><span class="label">หมายเลขห้อง:</span> <?php echo htmlspecialchars($room['room_num']); ?></p>
                    <p><span class="label">ราคา:</span> <?php echo htmlspecialchars($room['price']); ?> บาท</p>
                    <p><span class="label">วันที่เริ่มพัก:</span> <?php echo !empty($room['date_of_stay']) ? $room['date_of_stay'] : 'ยังไม่บันทึกข้อมูล'; ?></p>
                    <p><span class="label">วันที่ออก:</span> <?php echo !empty($room['date_of_out']) ? $room['date_of_out'] : 'ยังไม่บันทึกข้อมูล'; ?></p>
                    <h3>ข้อมูลผู้เช่า</h3>
                    <p><span class="label">ชื่อผู้เช่า:</span> <?php echo !empty($room['name']) ? htmlspecialchars($room['name']) : 'ยังไม่บันทึกข้อมูล'; ?></p>
                    <p><span class="label">อีเมล์:</span> <?php echo !empty($room['email']) ? htmlspecialchars($room['email']) : 'ยังไม่บันทึกข้อมูล'; ?></p>
                    <p><span class="label">เบอร์โทร:</span> <?php echo !empty($room['phonenumber']) ? htmlspecialchars($room['phonenumber']) : 'ยังไม่บันทึกข้อมูล'; ?></p>
                    <p><span class="label">ที่อยู่:</span> <?php echo !empty($room['address']) ? htmlspecialchars($room['address']) : 'ยังไม่บันทึกข้อมูล'; ?></p>
                    <p><span class="label">เลขบัตรประชาชน:</span> <?php echo !empty($room['idcard']) ? htmlspecialchars($room['idcard']) : 'ยังไม่บันทึกข้อมูล'; ?></p>
                </div>
            <?php else: ?>
                <p><?php echo $error_message; ?></p>
            <?php endif; ?>
            <a href="../index.php" class="btn btn-primary">กลับ</a>
        </div>
    </div>
</body>
</html>


    <!-- Edit Room Modal -->
    <!-- <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true" style="color: black;">

        <div class="modal-dialog">
            <div class="modal-content">
                <form id="editForm" method="POST" action="update_room.php">
                    <input type="hidden" name="room_id" value="<?php echo $room['id']; ?>">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editModalLabel">แก้ไขข้อมูลห้องพัก</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                         Room Form -->
                        <!-- <div class="mb-3">
                            <label for="room_num" class="form-label">หมายเลขห้อง</label>
                            <input type="text" class="form-control" id="room_num" name="room_num" value="<?php //echo htmlspecialchars($room['room_num']); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="price" class="form-label">ราคา</label>
                            <input type="number" class="form-control" id="price" name="price" value="<?php //echo htmlspecialchars($room['price']); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="status" class="form-label">สถานะ</label>
                            <select class="form-control" id="status" name="status">
                                <option value="available" <?php //echo ($room['status'] == 'available') ? 'selected' : ''; ?>>ว่าง</option>
                                <option value="unavailable" <?php //echo ($room['status'] == 'unavailable') ? 'selected' : ''; ?>>ไม่ว่าง</option>
                            </select>
                        </div> -->
                        <!-- Tenant Form -->
                        <!-- <h4>ข้อมูลผู้เช่า</h4>
                        <div class="mb-3">
                            <label for="tenant_name" class="form-label">ชื่อผู้เช่า</label>
                            <input type="text" class="form-control" id="tenant_name" name="tenant_name" value="<?php //echo htmlspecialchars($room['name']); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="tenant_email" class="form-label">อีเมล์</label>
                            <input type="email" class="form-control" id="tenant_email" name="tenant_email" value="<?php //echo htmlspecialchars($room['email']); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="tenant_phonenumber" class="form-label">เบอร์โทร</label>
                            <input type="text" class="form-control" id="tenant_phonenumber" name="tenant_phonenumber" value="<?php //echo htmlspecialchars($room['phonenumber']); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="tenant_address" class="form-label">ที่อยู่</label>
                            <input type="text" class="form-control" id="tenant_address" name="tenant_address" value="<?php //echo htmlspecialchars($room['address']); ?>">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ปิด</button>
                        <button type="submit" class="btn btn-primary">บันทึกการเปลี่ยนแปลง</button>
                    </div>
                </form>
            </div>
        </div>
    </div> --> 

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
</body>
</html>
