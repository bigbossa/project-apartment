<?php
include '../condb.php'; // เชื่อมต่อกับฐานข้อมูล

// ดึงข้อมูลจากตาราง Rooms
$sql = "SELECT id, room_num, status FROM Rooms";

// รันคำสั่ง SQL
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ข้อมูลห้องพัก</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            background-color: #191c24;
            color: white;
            font-family: Arial, sans-serif;
        }

        .container-fluid {
            width: 100%;
            padding: 20px;
        }

        .content-wrapper {
            background-color: #242731;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            max-width: 1200px;
            margin: 0 auto;
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        /* การ์ด */
        .card {
            border: 1px solid #000;
            border-radius: 8px;
            padding: 10px;
            height: 100px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            color: black;
        }

        .card:hover {
            transform: scale(1.05);
        }

        .card-header {
            font-size: 18px;
            font-weight: bold;
            text-align: center;
        }

        .card-body {
            font-size: 14px;
        }

        /* Layout ของการ์ด */
        .card-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }

        /* สถานะห้อง */
        .available {
            background-color: #32CD32;
        }

        .unavailable {
            background-color: #FF6347;
        }

        /* ลิงก์การ์ด */
        .card-link {
            text-decoration: none;
            color: inherit;
        }

        .card-link:hover {
            text-decoration: none;
        }
    </style>
</head>

<body>
    <div class="container-fluid">
        <div class="content-wrapper">
            <h1>ข้อมูลห้องพัก</h1>
            <div class="card-container">
                <?php
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $statusClass = ($row["status"] == 'available') ? 'available' : 'unavailable';
                        $statusText = ($row["status"] == 'available') ? 'ว่าง' : 'ไม่ว่าง';
                        echo "<a href='Content/RoomDetail.php?id=" . $row["id"] . "' class='card-link'>
                            <div class='card $statusClass'>
                                <div class='card-header'>ห้อง " . $row["room_num"] . "</div>
                                <div class='card-body'>สถานะ: " . $statusText . "</div>
                            </div>
                        </a>";
                    }
                } else {
                    echo "<p>ไม่มีข้อมูลห้องพัก</p>";
                }
                ?>
            </div>
        </div>
    </div>
</body>

</html>

<?php
$conn->close();
?>
