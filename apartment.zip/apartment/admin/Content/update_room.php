<?php
include '../../condb.php'; // เชื่อมต่อกับฐานข้อมูล

// ตรวจสอบว่ามีการส่งข้อมูล POST มาหรือไม่
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // รับค่าจากฟอร์ม
    $room_id = isset($_POST['room_id']) ? $_POST['room_id'] : 0;
    $room_num = isset($_POST['room_num']) ? $_POST['room_num'] : '';
    $price = isset($_POST['price']) ? $_POST['price'] : '';
    $status = isset($_POST['status']) ? $_POST['status'] : '';
    $date_of_stay = isset($_POST['date_of_stay']) ? $_POST['date_of_stay'] : '';
    $date_of_out = isset($_POST['date_of_out']) ? $_POST['date_of_out'] : '';
    $e_unit = isset($_POST['e_unit']) ? $_POST['e_unit'] : '';
    $w_unit = isset($_POST['w_unit']) ? $_POST['w_unit'] : '';
    $profile_id = isset($_POST['profile_id']) ? $_POST['profile_id'] : null; // ค่าผู้เช่า

    // ตรวจสอบค่าห้องพักที่สำคัญ
    if ($room_id > 0) {
        // สร้างคำสั่ง SQL สำหรับอัพเดทข้อมูล
        $sql = "UPDATE Rooms SET 
                    id = '$id',
                    room_num = '$room_num', 
                    price = '$price', 
                    status = '$status', 
                    date_of_stay = '$date_of_stay', 
                    date_of_out = '$date_of_out', 
                    e_unit = '$e_unit', 
                    w_unit = '$w_unit', 
                    profile_id = " . ($profile_id ? $profile_id : 'NULL') . " 
                WHERE id = $room_id";

        // รันคำสั่ง SQL
        if ($conn->query($sql) === TRUE) {
            // ถ้าการอัพเดทสำเร็จ
            echo "<script>
                    alert('อัพเดทข้อมูลห้องพักสำเร็จ');
                    window.location.href = 'RoomDetail.php?id=$room_id';  // รีไดเรคกลับไปหน้าเดิม
                  </script>";
        } else {
            // ถ้าการอัพเดทไม่สำเร็จ
            echo "<script>
                    alert('เกิดข้อผิดพลาดในการอัพเดทข้อมูล');
                  </script>";
        }
    }
}

$conn->close();
?>
