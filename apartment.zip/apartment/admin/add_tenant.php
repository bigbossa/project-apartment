<?php
session_start();
include '../condb.php'; // เชื่อมต่อกับฐานข้อมูล

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // รับค่าจากฟอร์ม
    $room_num = $_POST['room_num'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phonenumber = $_POST['phonenumber'];
    $address = $_POST['address'];
    $idcard = $_POST['idcard'];
    

    // ตรวจสอบว่าเลขห้องมีอยู่ในตาราง Rooms หรือไม่
    $checkRoom = $conn->prepare("SELECT * FROM Rooms WHERE room_num = ? AND status = 'available'");
    $checkRoom->bind_param("s", $room_num);
    $checkRoom->execute();
    $result = $checkRoom->get_result();

    if ($result->num_rows > 0) {
        // ถ้าเลขห้องมีอยู่ ให้เพิ่มข้อมูลผู้เช่าใน Tenants และอัปเดตสถานะห้อง
        $insertTenant = $conn->prepare("INSERT INTO profile (room_num, name, email, phonenumber, address, idcard) VALUES (?, ?, ?, ?, ?, ?)");
        $insertTenant->bind_param("ssssss", $room_num, $name, $email, $phonenumber, $address, $idcard);

        if ($insertTenant->execute()) {
            // อัปเดตสถานะห้องเป็น "unavailable"
            $updateRoom = $conn->prepare("UPDATE Rooms SET status = 'unavailable' WHERE room_num = ?");
            $updateRoom->bind_param("s", $room_num);
            $updateRoom->execute();

            echo "<script>alert('เพิ่มข้อมูลผู้เช่าสำเร็จและอัปเดตสถานะห้องแล้ว!'); window.location.href = 'index.php';</script>";
        } else {
            echo "เกิดข้อผิดพลาด: " . $conn->error;
        }
    } else {
        echo "<script>alert('ไม่พบหมายเลขห้อง หรือห้องไม่ว่าง!'); history.back();</script>";
    }
}

// ปิดการเชื่อมต่อฐานข้อมูล
$conn->close();
?>
