<?php
// เริ่มต้น session เพื่อเข้าถึงข้อมูล session ที่เก็บไว้
session_start();

// ตรวจสอบว่า session 'role' เป็น 'admin' หรือไม่
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    // ถ้าไม่ใช่ admin หรือไม่มี session 'role' แสดงว่าไม่ได้รับสิทธิ์
    header("Location: ../login.php");  // เปลี่ยนเส้นทางไปยังหน้า login
    exit();
}

// นำ Template ส่วนหัว และ Navbar มาแสดง (เพิ่มโค้ด include หากจำเป็น)
// include '../Template/head.php';
// include '../Template/Navbar.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>แก้ไขข้อมูลส่วนตัว</title>
    <style>
        body {
            background-color: #1c1c1e; /* สีพื้นหลังเข้ม */
            color: #fff; /* สีข้อความขาว */
            font-family: 'Arial', sans-serif; /* ฟอนต์ที่เรียบง่าย */
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 20px auto;
            background: #2c2c2e; /* สีอ่อนกว่าสีพื้นหลัง */
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #fff; /* สีข้อความขาว */
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        label {
            font-weight: bold;
        }

        input[type="text"],
        input[type="email"],
        input[type="tel"],
        select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        .row {
            display: flex;
            gap: 10px;
        }

        .row .form-group {
            flex: 1;
        }

        input[type="file"] {
            padding: 5px;
        }

        .submit-btn {
            background-color: #28a745;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }

        .submit-btn:hover {
            background-color: #218838;
        }

        .profile-pic {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 10px;
        }

        .profile-pic img {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            border: 2px solid #ccc; /* ขอบสีเทา */
            background-color: #fff; /* พื้นหลังสีขาว */
            object-fit: cover;
        }

        .required {
            color: red;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>แก้ไขข้อมูลส่วนตัว</h1>
    <form>
        <div class="profile-pic">
            <label for="profile-pic">รูปโปรไฟล์</label>
            <img src="default-profile.png" alt="Default Profile">
            <input type="file" id="profile-pic" accept="image/*">
        </div>
        <div class="row">
        <div class="row">
            <div class="form-group">
                <label for="name">แก้ไขชื่อ <span class="required">*</span></label>
                <input type="text" id="name" required>
            </div>
        </div>

        <div class="form-group">
            <label for="email">อีเมล <span class="required">*</span></label>
            <input type="email" id="email"  required>
        </div>

        <button type="submit" class="submit-btn">แก้ไขข้อมูล</button>
    </form>
</div>
</body>
</html>
