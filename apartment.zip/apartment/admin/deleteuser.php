<?php
session_start();

// เชื่อมต่อกับฐานข้อมูล
require '../dbcon.php';

// ตรวจสอบว่าเป็นผู้ใช้ที่ล็อกอินเข้ามาหรือไม่
if (!isset($_SESSION['user_id'])) {
    // หากไม่ได้ล็อกอิน ให้กลับไปที่หน้า login
    header("Location: ../login.php");
    exit();
}

// ตรวจสอบว่าเป็น admin หรือไม่ หากไม่ใช่ให้ไม่สามารถเข้าถึงหน้านี้ได้
if ($_SESSION['role'] != 'admin') {
    echo '<script>
            window.onload = function() {
                Swal.fire("Access Denied", "คุณไม่มีสิทธิ์เข้าถึงหน้านี้", "error").then(() => {
                    window.location.href = "../login.php";
                });
            };
          </script>';
    exit();
}

// ตรวจสอบว่าได้ส่งค่า id มาหรือไม่
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $user_id = $_GET['id'];

    // เตรียมคำสั่ง SQL สำหรับลบข้อมูลผู้ใช้
    $sql = "DELETE FROM profile WHERE id = ?";
    
    // ใช้ prepared statement เพื่อป้องกัน SQL injection
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("i", $user_id);  // 'i' คือ integer
        if ($stmt->execute()) {
            // ลบข้อมูลสำเร็จ
            echo '<script>
                    window.onload = function() {
                        Swal.fire("Deleted!", "User has been deleted successfully.", "success").then(() => {
                            window.location.href = "index_ShowUser.php";
                        });
                    };
                  </script>';
        } else {
            echo '<script>
                    window.onload = function() {
                        Swal.fire("Error", "Error deleting user: ' . $conn->error . '", "error");
                    };
                  </script>';
        }
    } else {
        echo '<script>
                window.onload = function() {
                    Swal.fire("Error", "Error preparing statement: ' . $conn->error . '", "error");
                };
              </script>';
    }
} else {
    echo '<script>
            window.onload = function() {
                Swal.fire("Error", "Invalid user ID.", "error").then(() => {
                    window.location.href = "index_ShowUser.php";
                });
            };
          </script>';
}

// ปิดการเชื่อมต่อฐานข้อมูล
$conn->close();
?>

<!-- เพิ่ม SweetAlert -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
