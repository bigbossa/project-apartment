<?php
session_start();

// ตรวจสอบสิทธิ์ admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

include '../Template/head.php';
include '../Template/sidebar/Sidebar_Showuser.php';
include '../Template/Navbar.php';

// เชื่อมต่อฐานข้อมูล
require '../dbcon.php';

// Pagination
$limit = 10; // Users per page
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Query ดึงข้อมูลผู้ใช้แบบแบ่งหน้า
$sql = "SELECT id, name, email, role FROM profile LIMIT $limit OFFSET $offset";
$result = $conn->query($sql);

// ดึงจำนวนข้อมูลทั้งหมดสำหรับ Pagination
$total_users = $conn->query("SELECT COUNT(*) AS total FROM profile")->fetch_assoc()['total'];
$total_pages = ceil($total_users / $limit);
?>

<div class="container-fluid pt-4 px-4">
    <div class="row vh-100 bg-secondary rounded align-items-center justify-content-center mx-0">
        <div class="col-md-10 text-center">
            <h2 class="mb-4">User List</h2>
            <table class="table table-hover table-striped table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result->num_rows > 0): ?>
                        <?php while ($user = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $user['id']; ?></td>
                                <td><?php echo htmlspecialchars($user['name']); ?></td>
                                <td><?php echo htmlspecialchars($user['email']); ?></td>
                                <td><?php echo htmlspecialchars($user['role']); ?></td>
                                <td>
                                    <a href="index_EditShowUser.php?id=<?php echo $user['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                                    <form method="POST" action="deleteuser.php" style="display:inline;" onsubmit="return confirm('Are you sure?');">
                                        <input type="hidden" name="id" value="<?php echo $user['id']; ?>">
                                        <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="5" class="text-center">No users found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <!-- Pagination Links -->
            <nav>
                <ul class="pagination justify-content-center">
                    <li class="page-item <?php echo ($page <= 1) ? 'disabled' : ''; ?>">
                        <a class="page-link" href="?page=<?php echo $page - 1; ?>">&laquo; Previous</a>
                    </li>
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <li class="page-item <?php echo ($i == $page) ? 'active' : ''; ?>">
                            <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                        </li>
                    <?php endfor; ?>
                    <li class="page-item <?php echo ($page >= $total_pages) ? 'disabled' : ''; ?>">
                        <a class="page-link" href="?page=<?php echo $page + 1; ?>">Next &raquo;</a>
                    </li>
                </ul>
            </nav>
        </div>
    </div>
</div>

<?php
$conn->close();
include '../Template/Footer.php';
include '../Template/Backtotop.php';
include '../Template/JavaScript.php';
?>
