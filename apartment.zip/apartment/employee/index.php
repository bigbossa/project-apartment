<?php

session_start();
if ($_SESSION['user_role'] != 'Tenant') {
    header("Location: index.php");
    exit();
}

    include '../Template/head.php';
    // include '../Template/Spinner.php';
    include '../Template/Sidebar.php';
    include '../Template/Navbar.php';
    // include '../Template/Content.php';
    include 'Content/1.php';
    include '../Template/Footer.php';
    include '../Template/Backtotop.php';
    include '../Template/JavaScript.php';

?>