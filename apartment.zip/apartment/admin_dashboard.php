<?php
session_start();
if ($_SESSION['user_role'] != 'Admin') {
    header("Location: index.php");
    exit();
}
echo "Welcome Admin, " . $_SESSION['user_name'];
?>
